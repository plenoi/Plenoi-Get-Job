'use strict';
// DOM behavior test, not browser rendering or Chromium QA.
const vm=require('node:vm'),fs=require('node:fs'),assert=require('node:assert/strict'),E=require('../../main-tree/engine');
async function harness(story,raw=null,{blocked=false,fetchFails=false}={}){
 class Element{constructor(){this.hidden=false;this.textContent='';this.children=[];}replaceChildren(){this.children=[];}append(x){this.children.push(x);}focus(){this.focused=true;}}
 const ids=['company','scope','disclaimer','notice','resume','save','restart','title','body','state','choices','ending'];const els=Object.fromEntries(ids.map(id=>[id,new Element()])),main=new Element();els.notice.textContent='กำลังอ่านบท…';els.resume.hidden=els.save.hidden=els.restart.hidden=true;main.hidden=true;
 const stored=new Map(raw===null?[]:[['plenoi-v1:'+story.position.position_id,raw]]);let confirm=true;
 const ctx={window:{BranchPilot:E},document:{getElementById:id=>els[id],querySelector:()=>main,createElement:()=>new Element()},fetch:async()=>({ok:!fetchFails,json:async()=>story}),crypto:{getRandomValues:a=>{a[0]=42;return a;}},Uint32Array,localStorage:{getItem:key=>stored.get(key)||null,setItem:(key,value)=>{if(blocked)throw new Error('blocked');stored.set(key,value);}},confirm:()=>confirm};
 await vm.runInNewContext(fs.readFileSync(__dirname+'/reader.js','utf8'),ctx);
 return {els,main,stored,setConfirm:v=>{confirm=v;},click:i=>els.choices.children[i].onclick(),key:'plenoi-v1:'+story.position.position_id};
}
(async()=>{
 const story=require('./story.json');let h=await harness(story);assert.equal(h.main.hidden,false);assert.equal(h.stored.size,0,'Page load must not overwrite a save');const oldChoice=h.els.choices.children[0];h.click(0);const savedAfterFirst=h.stored.get(h.key);oldChoice.onclick();assert.equal(h.stored.get(h.key),savedAfterFirst,'A stale double-click must not advance the next scene');let raw=h.stored.get(h.key),run=E.restore(story,raw);assert.equal(run.node,'reconcile-m1');h=await harness(story,raw);assert.equal(h.els.resume.hidden,false);assert.equal(h.main.hidden,true);h.els.resume.onclick();assert.equal(h.els.title.textContent,story.nodes.find(n=>n.id===run.node).title);h.setConfirm(false);h.els.restart.onclick();assert.equal(h.stored.get(h.key),raw);h.setConfirm(true);h.els.restart.onclick();assert.equal(E.restore(story,h.stored.get(h.key)).node,story.start);
 h=await harness(story,'corrupt');assert.equal(h.stored.get(h.key),'corrupt');assert.match(h.els.notice.textContent,/อ่านบันทึกเดิมไม่ได้/);h.click(0);assert.equal(E.restore(story,h.stored.get(h.key)).node,'reconcile-m1');
 h=await harness(story,null,{blocked:true});h.click(0);assert.match(h.els.notice.textContent,/ไม่อนุญาตให้บันทึก/);assert.equal(h.stored.size,0);assert.match(h.els.title.textContent,/./);
 h=await harness(story,null,{fetchFails:true});assert.match(h.els.notice.textContent,/เปิดบททดลองไม่ได้/);
 console.log('PASS: DOM logic for fresh start, saved resume, cancel/confirm restart, corrupt save, blocked storage, fetch error. No browser rendering claimed.');
})().catch(e=>{console.error(e);process.exitCode=1;});
