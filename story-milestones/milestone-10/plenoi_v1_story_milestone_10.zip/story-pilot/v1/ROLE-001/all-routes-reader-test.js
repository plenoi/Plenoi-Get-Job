'use strict';

// Exercises reader.js against a minimal DOM, not a browser or visual rendering.
// Run build.js for the intended block count, then test.js, then this file.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const engine = require('../../main-tree/engine');
const story = JSON.parse(fs.readFileSync(path.join(__dirname, 'story.json'), 'utf8'));
const validation = JSON.parse(fs.readFileSync(path.join(__dirname, 'validation.json'), 'utf8'));
const readerSource = fs.readFileSync(path.join(__dirname, 'reader.js'), 'utf8');
const nodes = new Map(story.nodes.map(node => [node.id, node]));
const key = 'plenoi-v1:' + story.position.position_id;

class Element {
  constructor() {
    this.hidden = false;
    this.textContent = '';
    this.children = [];
    this.focused = false;
  }
  replaceChildren() { this.children = []; }
  append(...children) { this.children.push(...children); }
  focus() { this.focused = true; }
}

async function harness(seed, raw = null) {
  const ids = ['company', 'scope', 'disclaimer', 'notice', 'resume', 'save',
    'restart', 'title', 'body', 'state', 'choices', 'ending'];
  const elements = Object.fromEntries(ids.map(id => [id, new Element()]));
  const main = new Element();
  main.hidden = true;
  elements.resume.hidden = elements.save.hidden = elements.restart.hidden = true;
  elements.notice.textContent = 'กำลังอ่านบท…';
  const storage = new Map(raw === null ? [] : [[key, raw]]);
  let writes = 0;
  let randomDraws = 0;
  const context = {
    window: { BranchPilot: engine },
    document: {
      getElementById: id => {
        assert.ok(elements[id], 'Unexpected element: ' + id);
        return elements[id];
      },
      querySelector: selector => {
        assert.equal(selector, 'main');
        return main;
      },
      createElement: tag => {
        assert.equal(tag, 'button');
        return new Element();
      }
    },
    fetch: async url => {
      assert.equal(url, 'story.json');
      return { ok: true, json: async () => story };
    },
    crypto: {
      getRandomValues: values => {
        assert.equal(values.length, 1);
        randomDraws++;
        values[0] = seed;
        return values;
      }
    },
    Uint32Array,
    confirm: () => true,
    localStorage: {
      getItem: storageKey => {
        assert.equal(storageKey, key);
        return storage.get(storageKey) ?? null;
      },
      setItem: (storageKey, value) => {
        assert.equal(storageKey, key);
        writes++;
        storage.set(storageKey, value);
      }
    }
  };
  await vm.runInNewContext(readerSource, context, { filename: 'reader.js' });
  return {
    elements, main,
    saved: () => storage.get(key),
    writes: () => writes,
    randomDraws: () => randomDraws
  };
}

function assertScene(h, run) {
  const nodeId=run.node;
  const node = nodes.get(nodeId);
  assert.ok(node, 'Missing scene: ' + nodeId);
  assert.equal(h.main.hidden, false, nodeId);
  assert.equal(h.elements.title.textContent, node.title, nodeId);
  assert.equal(h.elements.body.textContent, node.text, nodeId);
  assert.equal(h.elements.state.hidden,!story.baselineNodeIds.includes(nodeId),nodeId);
  assert.equal(h.elements.state.textContent,'ค่าจำลองเฉพาะเรื่อง ไม่ใช่คะแนนจริง: หลักฐาน '+run.state.evidence+' · อารมณ์ '+run.state.mood,nodeId);
  assert.equal(h.elements.choices.children.length, node.choices.length, nodeId);
  node.choices.forEach((choice, index) => {
    assert.equal(h.elements.choices.children[index].textContent, choice.label, nodeId);
  });
  assert.equal(Boolean(h.elements.ending.textContent), Boolean(node.ending), nodeId);
}

(async () => {
  assert.equal(validation.revision, story.revision,
    'Validation is stale. Run test.js against the current story first.');
  assert.ok(Array.isArray(validation.paths) && validation.paths.length > 0);
  assert.ok(validation.seedWitnesses && typeof validation.seedWitnesses === 'object');
  const expectedEndings = story.nodes.filter(node => node.ending).map(node => node.id).sort();
  assert.deepEqual(Object.keys(validation.seedWitnesses).sort(), expectedEndings,
    'Every ending must have a saved-seed witness.');
  const pathsByEnding = new Map(validation.paths.map(route => [route.at(-1), route]));
  assert.equal(pathsByEnding.size, validation.paths.length,
    'This test expects one validated complete path per ending.');
  assert.deepEqual([...pathsByEnding.keys()].sort(), expectedEndings);

  let routesChecked = 0;
  let transitionsChecked = 0;
  for (const endingId of expectedEndings) {
    const witness = validation.seedWitnesses[endingId];
    const h = await harness(witness.seed);
    let run = engine.start(story, witness.seed);
    const visited = [run.node];
    assertScene(h, run);
    assert.equal(h.writes(), 0, 'Opening a new route must not write a save.');
    assert.equal(h.randomDraws(), 1);
    for (const index of witness.history) {
      const oldButton = h.elements.choices.children[index];
      assert.ok(oldButton, 'Missing choice on route to ' + endingId);
      oldButton.onclick();
      run = engine.choose(story, run, index);
      visited.push(run.node);
      assertScene(h, run);
      assert.deepEqual(engine.restore(story, h.saved()), run);
      const raw = h.saved();
      const writes = h.writes();
      oldButton.onclick();
      assert.equal(h.saved(), raw, 'Stale click changed the save: ' + endingId);
      assert.equal(h.writes(), writes, 'Stale click wrote storage: ' + endingId);
      assertScene(h, run);
      transitionsChecked++;
    }
    assert.equal(run.node, endingId);
    assert.deepEqual(visited, pathsByEnding.get(endingId));
    assert.equal(h.writes(), witness.history.length);

    // A different potential fresh seed must not affect restoring the saved run.
    const resumed = await harness((witness.seed + 1) >>> 0, h.saved());
    assert.equal(resumed.main.hidden, true);
    assert.equal(resumed.elements.resume.hidden, false);
    assert.equal(resumed.writes(), 0);
    assert.equal(resumed.randomDraws(), 0, 'Loading a save must not generate a new seed.');
    resumed.elements.resume.onclick();
    assertScene(resumed, run);
    assert.equal(resumed.saved(), h.saved());
    assert.equal(resumed.writes(), 0, 'Resume must not replace the existing save.');
    routesChecked++;
  }
  console.log('PASS: ' + routesChecked + ' complete routes; ' + transitionsChecked +
    ' choice transitions with save/replay and stale-click checks; every ending resumes.');
  console.log('Revision: ' + story.revision + '. DOM logic only; no browser rendering claimed.');
})().catch(error => {
  console.error(error);
  process.exitCode = 1;
});
