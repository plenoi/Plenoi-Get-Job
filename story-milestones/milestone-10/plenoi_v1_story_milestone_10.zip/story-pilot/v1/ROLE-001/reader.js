'use strict';
(async function(){
 const $=id=>document.getElementById(id),engine=window.BranchPilot;
 try{
  const response=await fetch('story.json');if(!response.ok)throw new Error('อ่านไฟล์บทไม่สำเร็จ');
  const story=await response.json(),key='plenoi-v1:'+story.position.position_id;let run=null,saved=null;
  const fresh=()=>engine.start(story,crypto.getRandomValues(new Uint32Array(1))[0]);
  $('company').textContent=story.position.company+' · '+story.position.position;$('scope').textContent=story.scope;$('disclaimer').textContent=story.disclaimer;
  const notice=text=>{$('notice').textContent=text;};
  function persist(){try{localStorage.setItem(key,engine.serialize(run));notice('บันทึกแล้ว กลับมาเล่นต่อจากคำตอบเดิมในเบราว์เซอร์นี้ได้');return true;}catch{notice('เบราว์เซอร์ไม่อนุญาตให้บันทึก เล่นต่อในแท็บนี้ได้ แต่ปิดแท็บแล้วจะเล่นต่อไม่ได้');return false;}}
  function render(focus=false){const presentedRun=run,node=story.nodes.find(n=>n.id===run.node);document.querySelector('main').hidden=false;$('title').textContent=node.title;$('body').textContent=node.text;$('state').hidden=!story.baselineNodeIds.includes(node.id);$('state').textContent='ค่าจำลองเฉพาะเรื่อง ไม่ใช่คะแนนจริง: หลักฐาน '+run.state.evidence+' · อารมณ์ '+run.state.mood;$('ending').textContent=node.ending?'จบเส้นทางนี้แล้ว เริ่มใหม่เพื่อสำรวจอีกทางได้':'';$('choices').replaceChildren();node.choices.forEach((c,i)=>{const b=document.createElement('button');b.textContent=c.label;b.onclick=()=>{if(run!==presentedRun)return;run=engine.choose(story,run,i);persist();render(true);};$('choices').append(b);});$('save').hidden=false;$('restart').hidden=false;$('resume').hidden=true;if(focus)$('title').focus();}
  $('save').onclick=persist;$('restart').onclick=()=>{if(!confirm('เริ่มใหม่และแทนที่บันทึกบทนี้หรือไม่?'))return;run=fresh();saved=null;persist();render(true);};$('resume').onclick=()=>{run=saved;render(true);notice('เล่นต่อจากบันทึกและคำตอบเดิมแล้ว');};
  try{const raw=localStorage.getItem(key);if(raw)saved=engine.restore(story,raw);}catch{notice('อ่านบันทึกเดิมไม่ได้หรือเป็นบทคนละฉบับ บันทึกจะยังไม่ถูกแทนที่จนกว่าจะเลือกคำตอบ กดบันทึก หรือเริ่มใหม่');}
  if(saved){$('resume').hidden=false;$('restart').hidden=false;notice('พบบันทึกเดิม เลือกเล่นต่อหรือเริ่มใหม่');}else{run=fresh();render();if($('notice').textContent==='กำลังอ่านบท…')notice('บันทึกอัตโนมัติเมื่อเลือกคำตอบ กลับมาเล่นต่อได้ในเบราว์เซอร์นี้');}
 }catch(e){$('notice').textContent='เปิดบททดลองไม่ได้: '+e.message;}
})();
