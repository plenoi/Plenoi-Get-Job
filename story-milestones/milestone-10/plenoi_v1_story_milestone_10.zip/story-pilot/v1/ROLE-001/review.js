'use strict';
(async()=>{
 const $=id=>document.getElementById(id);
 try{
  const response=await fetch('story.json');if(!response.ok)throw new Error('อ่านไฟล์บทไม่สำเร็จ');const story=await response.json(),nodes=new Map(story.nodes.map(n=>[n.id,n])),paths=[];
  function walk(id,path){if(path.includes(id))throw new Error('พบวงวนในเส้นทาง');if(paths.length>1000)throw new Error('จำนวนเส้นทางเกินขอบเขตตัวอ่านฉบับนี้');const n=nodes.get(id);if(!n)throw new Error('ไม่พบฉากในเส้นทาง');const next=[...path,id];if(n.ending){paths.push(next);return;}for(const choice of n.choices)for(const target of choice.randomTo||[choice.to])walk(target,next);}
  walk(story.start,[]);$('scope').textContent=story.scope;$('disclaimer').textContent=story.disclaimer;
  paths.forEach((p,i)=>{const option=document.createElement('option');option.value=String(i);option.textContent=(i+1)+'. '+nodes.get(p.at(-1)).title;$('route').append(option);});$('route').disabled=false;
  function render(){const p=paths[Number($('route').value)||0];$('scenes').replaceChildren();$('notice').textContent='อ่าน '+p.length+' ฉาก รวมบทสัมภาษณ์และบทส่งท้าย · '+paths.length+' เส้นทางในชุดนี้';p.forEach((id,i)=>{const n=nodes.get(id),section=document.createElement('section'),heading=document.createElement('h2'),body=document.createElement('p');heading.textContent=n.title;body.className='prose';body.textContent=n.text;section.append(heading,body);if(i<p.length-1){const choice=n.choices.find(c=>c.to===p[i+1]||(c.randomTo||[]).includes(p[i+1])),decision=document.createElement('p');decision.className='decision';decision.textContent=(choice.randomTo?'หลังการตัดสินใจนี้ เกิดสถานการณ์สุ่มตามบทถัดไป: ':'ทางที่เลือก: ')+choice.label;section.append(decision);}$('scenes').append(section);});}
  $('route').onchange=render;render();
 }catch(e){$('notice').textContent='เปิดบทสำหรับทบทวนไม่ได้: '+e.message;}
})();
