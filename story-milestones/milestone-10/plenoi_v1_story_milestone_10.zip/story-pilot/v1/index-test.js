'use strict';
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const code=fs.readFileSync(path.join(__dirname,'index.js'),'utf8');
class Element{constructor(tag){this.tag=tag;this.children=[];this.textContent='';}appendChild(child){this.children.push(child);return child;}}
async function render(data,ok=true){const elements={summary:new Element('p'),roles:new Element('ul')};const document={getElementById:id=>elements[id],createElement:tag=>new Element(tag),createTextNode:text=>({textContent:text})};await vm.runInNewContext(code,{document,fetch:async(url,options)=>{assert.equal(url,'progress.json');assert.equal(options.cache,'no-store');return{ok,json:async()=>data};}});return elements;}
(async()=>{
 const progress=JSON.parse(fs.readFileSync(path.join(__dirname,'progress.json'))),result=await render(progress);
 const ready=progress.roles.filter(r=>r.phase==='story_and_dom_verified_browser_pending');assert.equal(result.roles.children.length,ready.length);
 for(let i=0;i<ready.length;i++){const links=result.roles.children[i].children.filter(n=>n.tag==='a');assert.deepEqual(links.map(n=>n.href),[ready[i].position_id+'/index.html',ready[i].position_id+'/review.html']);for(const n of links)assert(fs.existsSync(path.join(__dirname,n.href)));}
 const bad=await render({roles:[{phase:'story_and_dom_verified_browser_pending',position_id:'../outside',active_story:'../outside/story.json'}],requested_positions:299});assert.equal(bad.roles.children.length,0);
 for(const [data,ok]of[[{},true],[progress,false]]){const failed=await render(data,ok);assert.equal(failed.roles.children.length,0);assert(failed.summary.textContent.includes('อ่านรายการบทไม่ได้'));}
 console.log('Text-only role index DOM checks passed; only current validated readers linked. No browser rendering claim.');
})().catch(error=>{console.error(error);process.exitCode=1;});
