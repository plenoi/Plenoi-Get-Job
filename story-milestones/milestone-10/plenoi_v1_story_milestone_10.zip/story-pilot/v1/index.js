'use strict';
(async()=>{
 const summary=document.getElementById('summary'),list=document.getElementById('roles');
 try{
  const response=await fetch('progress.json',{cache:'no-store'});if(!response.ok)throw new Error('status');
  const progress=await response.json();if(!Array.isArray(progress.roles))throw new Error('format');
  const ready=progress.roles.filter(r=>r.phase==='story_and_dom_verified_browser_pending'&&/^ROLE-\d{3}$/.test(r.position_id)&&r.active_story===r.position_id+'/story.json');
  summary.textContent=`บทที่ตรวจโครงสร้างและตัวอ่านจำลองแล้ว ${ready.length} ตำแหน่ง จากขอบเขต ${progress.requested_positions} ตำแหน่ง ยังไม่นับว่าเกมทั้งหมดเสร็จ`;
  for(const role of ready){
   const li=document.createElement('li'),name=document.createElement('strong');name.textContent=role.company+' · '+role.position;li.appendChild(name);
   const count=document.createElement('small');count.textContent=`${role.source_nodes} ฉาก / ${role.verified_routes} เส้นทาง รวมบทหลักและบทเพิ่มเติม`;li.appendChild(count);
   for(const [file,label]of[['index.html','เปิดตัวอ่านและเล่นต่อ'],['review.html','อ่านต้นฉบับและเส้นทางทั้งหมด']]){const a=document.createElement('a');a.href=role.position_id+'/'+file;a.textContent=label;li.appendChild(a);li.appendChild(document.createTextNode(' '));}
   list.appendChild(li);
  }
 }catch(e){summary.textContent='อ่านรายการบทไม่ได้ โปรดเปิดผ่านเซิร์ฟเวอร์โครงการและลองใหม่ ไม่มีข้อมูลบันทึกการเล่นถูกแก้ไข';}
})();
