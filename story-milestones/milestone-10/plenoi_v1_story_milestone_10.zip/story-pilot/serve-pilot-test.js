'use strict';
const assert=require('node:assert/strict'),http=require('node:http'),{createServer}=require('./serve-pilot');
(async()=>{const server=createServer();await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});try{
 const port=server.address().port;async function request(url,method='GET'){return new Promise((resolve,reject)=>{const req=http.request({host:'127.0.0.1',port,path:url,method},res=>{let body='';res.setEncoding('utf8');res.on('data',chunk=>body+=chunk);res.on('end',()=>resolve({status:res.statusCode,headers:res.headers,body}));});req.on('error',reject);req.end();});}
 assert.equal((await request('/')).headers.location,'/v1/');const index=await request('/v1/');assert.equal(index.status,200);assert(index.body.includes('Plenoi-Get-Job'));assert(index.headers['content-type'].startsWith('text/html'));
 const progress=await request('/v1/progress.json?fresh=1');assert.equal(progress.status,200);assert.equal(JSON.parse(progress.body).requested_positions,299);assert.equal(progress.headers['cache-control'],'no-store');
 assert.equal((await request('/v1/','HEAD')).body,'');assert.equal((await request('/v1/','POST')).status,405);assert.equal((await request('/%2e%2e/package.json')).status,400);assert.equal((await request('/%00')).status,400);assert.equal((await request('/bad%')).status,400);assert.equal((await request('/missing-file')).status,404);
 console.log('Local-only HTTP serving, MIME, read-only methods and path checks passed. This is not browser rendering QA.');
 }finally{await new Promise(resolve=>server.close(resolve));}})().catch(error=>{console.error(error);process.exitCode=1;});
