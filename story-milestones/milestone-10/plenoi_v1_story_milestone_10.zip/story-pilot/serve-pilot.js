'use strict';
// Local-only text story server. No dependencies, uploads or external services.
const http=require('node:http'),fs=require('node:fs'),path=require('node:path');
const root=fs.realpathSync(__dirname),types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.css':'text/css; charset=utf-8','.md':'text/plain; charset=utf-8'};
function createServer(){return http.createServer((req,res)=>{
 const send=(code,text)=>{res.writeHead(code,{'Content-Type':'text/plain; charset=utf-8','Cache-Control':'no-store'});res.end(req.method==='HEAD'?'':text);};
 if(!['GET','HEAD'].includes(req.method)){res.setHeader('Allow','GET, HEAD');return send(405,'Read-only server');}
 let pathname;try{pathname=decodeURIComponent(req.url.split('?')[0]);}catch{return send(400,'Invalid path');}
 if(pathname.includes('\0')||pathname.includes('\\')||pathname.split('/').includes('..'))return send(400,'Invalid path');
 if(pathname==='/'){res.writeHead(302,{Location:'/v1/'});return res.end();}
 let file=path.resolve(root,'.'+pathname);try{if(fs.statSync(file).isDirectory())file=path.join(file,'index.html');file=fs.realpathSync(file);}catch{return send(404,'Not found');}
 if(!file.startsWith(root+path.sep)||!fs.statSync(file).isFile())return send(404,'Not found');
 res.writeHead(200,{'Content-Type':types[path.extname(file)]||'application/octet-stream','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
 if(req.method==='HEAD')return res.end();const stream=fs.createReadStream(file);stream.on('error',()=>res.destroy());stream.pipe(res);
 });}
if(require.main===module){const port=Number(process.env.PORT||4182);if(!Number.isInteger(port)||port<1||port>65535)throw new Error('PORT must be1–65535');const server=createServer();server.on('error',error=>{console.error(error.message);process.exitCode=1;});server.listen(port,'127.0.0.1',()=>console.log(`Local text reader: http://127.0.0.1:${port}/v1/`));}
module.exports={createServer};
