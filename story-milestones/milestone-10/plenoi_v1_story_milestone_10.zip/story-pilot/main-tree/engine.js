(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.BranchPilot=factory();})(typeof globalThis==='object'?globalThis:this,function(){
'use strict';
function randomIndex(seed,nodeId,count){
 let h=(seed^2166136261)>>>0;
 for(const ch of nodeId){h=Math.imul(h^ch.charCodeAt(0),16777619)>>>0;}
 h^=h>>>16;h=Math.imul(h,0x7feb352d)>>>0;h^=h>>>15;h=Math.imul(h,0x846ca68b)>>>0;h^=h>>>16;
 return (h>>>0)%count;
}
function record(value){return value!==null&&typeof value==='object'&&!Array.isArray(value)&&(Object.getPrototypeOf(value)===Object.prototype||Object.getPrototypeOf(value)===null);}
function checkRequirements(node,state){
 if(node.requires===undefined)return;
 if(!record(node.requires))throw new Error('เงื่อนไขฉากไม่ถูกต้อง');
 for(const [key,bounds] of Object.entries(node.requires)){
  if(!Object.hasOwn(state,key)||!record(bounds)||!Object.keys(bounds).length||Object.keys(bounds).some(k=>!['min','max'].includes(k))||Object.values(bounds).some(v=>!Number.isFinite(v))||(bounds.min!==undefined&&bounds.max!==undefined&&bounds.min>bounds.max))throw new Error('เงื่อนไขฉากไม่ถูกต้อง');
  if((bounds.min!==undefined&&state[key]<bounds.min)||(bounds.max!==undefined&&state[key]>bounds.max))throw new Error('ค่าสถานะไม่สอดคล้องกับเส้นทางนี้');
 }
}
function start(story,seed){
 if(!Number.isInteger(seed)||seed<0||seed>0xffffffff)throw new Error('เมล็ดสุ่มไม่ถูกต้อง');
 if(story.initialState!==undefined&&!record(story.initialState))throw new Error('ค่าสถานะเริ่มต้นไม่ถูกต้อง');
 const state={...(story.initialState||{})};
 for(const value of Object.values(state))if(!Number.isFinite(value))throw new Error('ค่าสถานะเริ่มต้นไม่ถูกต้อง');
 const node=story.nodes.find(n=>n.id===story.start);if(!node)throw new Error('ไม่พบฉากเริ่มต้น');checkRequirements(node,state);
 return {revision:story.revision,position:story.position.position_id,seed,node:story.start,state,history:[]};
}
function choose(story,run,index){
 const node=story.nodes.find(n=>n.id===run.node),choice=node&&node.choices[index];
 if(!Number.isInteger(index)||!choice)throw new Error('ทางเลือกไม่ถูกต้อง');
 const next=choice.randomTo?choice.randomTo[randomIndex(run.seed,node.id,choice.randomTo.length)]:choice.to;
 const target=story.nodes.find(n=>n.id===next);
 if(!target)throw new Error('ไม่พบฉากถัดไป');
 const state={...run.state};
 if(choice.effects!==undefined&&!record(choice.effects))throw new Error('การเปลี่ยนค่าสถานะไม่ถูกต้อง');
 for(const [key,delta] of Object.entries(choice.effects||{})){
  if(!Object.hasOwn(state,key)||!Number.isFinite(delta))throw new Error('การเปลี่ยนค่าสถานะไม่ถูกต้อง');
  state[key]+=delta;if(!Number.isFinite(state[key]))throw new Error('ค่าสถานะไม่ถูกต้อง');
 }
 checkRequirements(target,state);
 return {...run,node:next,state,history:[...run.history,index]};
}
function serialize(run){return JSON.stringify({revision:run.revision,position:run.position,seed:run.seed,history:run.history});}
function restore(story,raw){
 const saved=JSON.parse(raw);
 if(!saved||saved.revision!==story.revision||saved.position!==story.position.position_id||!Array.isArray(saved.history)||saved.history.length>100)throw new Error('บันทึกไม่ตรงกับบทฉบับนี้');
 let run=start(story,saved.seed);for(const i of saved.history)run=choose(story,run,i);return run;
}
return {start,choose,serialize,restore,randomIndex};
});
